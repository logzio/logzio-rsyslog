#!/bin/bash

# ---------------------------------------- 
# Setup dependencies
# ---------------------------------------- 
source $LOGZ_DIR/configure_linux.sh "false"


# ---------------------------------------- 
# Setup variables
# ---------------------------------------- 

FILE_NAME=""
FILE_PATH=""
TAG=""
RSYSLOG_FILENAME="21-logzio-${FILE_NAME}-${TAG}"


# ---------------------------------------- 
# initiate rsyslog a custom linux conf installation, for single
# file and directories, and validate compatibility 
# ---------------------------------------- 
function install_rsyslog_linux_conf {
	# initiate rsyslog conf installation and validate compatibility 
	install_rsyslog_conf

	log "INFO" "Configure rsyslog for $RSYSLOG_FILENAME"

	# validate file compatibility requirements are reached.
	validate_file_compatibility
}

function validate_file_compatibility {
	# validate that the file name dose not contain spaces, and it exist
	validate_file_path

	if is_directory; then
		monitor_directory
	else
		monitor_file
	fi

	# validate that logs are been sent
	validate_rsyslog_logzio_installation ${RSYSLOG_FILENAME}

	log "INFO" "Rsyslog $RSYSLOG_FILENAME conf has been successfully configured on you system."
}


# ---------------------------------------- 
# validate that the file name dose not contain spaces
# and that it exist under the specified path
# ---------------------------------------- 
function validate_file_path {
	pattern=" |'"
	if [[ $FILE_PATH =~ $pattern ]]; then
		log "ERROR" "White spaces are not allowed, File path: $FILE_PATH"
		exit 1
	fi

	if [[ ! -f $FILE_PATH ]]; then
		log "ERROR" "Cannot find file under: $FILE_PATH."
		log "ERROR" "Please validate that you specify the correct file path"
		exit 1
	fi
}

function monitor_directory {

}

function monitor_file {
	
}




# executing the script for loggly to install and configure syslog
installLogglyConfForFile()
{
	#log message indicating starting of Loggly configuration
	logMsgToConfigSysLog "INFO" "INFO: Initiating configure Loggly for file monitoring."

	#check if the linux environment is compatible for Loggly
	checkLinuxLogglyCompatibility

	#checks if the file name contain spaces, if yes, the exit
	checkIfFileLocationContainSpaces
	
	#check if the alias is already taken
	checkIfFileAliasExist
	
	if [ "$IS_DIRECTORY" == "true" ]; then
		
		configureDirectoryFileMonitoring
	
	else
				
		#check if file to monitor exists
		checkIfFileExist
		
		#construct variables using filename and filealias
		constructFileVariables
		
		#check for the log file size
		checkLogFileSize $LOGGLY_FILE_TO_MONITOR
		
		#checks if the file has proper read permission
		checkFileReadPermission
		
		#configure loggly for Linux
		installLogglyConf
		
		#multiple tags
		addTagsInConfiguration
		
		#create 21<file alias>.conf file
		write21ConfFileContents
		
	fi
	
	#restart rsyslog
	restartRsyslog

	#verify if the file logs made it to loggly
	checkIfFileLogsMadeToLoggly
	
	
	if [ "$IS_FILE_MONITOR_SCRIPT_INVOKED" = "false" ]; then
			#log success message
			logMsgToConfigSysLog "SUCCESS" "SUCCESS: Successfully configured to send $LOGGLY_FILE_TO_MONITOR logs via Loggly."
	fi
}


# ---------------------------------------- 
# get the script parameters
# ---------------------------------------- 

# if the script is been included in anther script, execution needs to be prevented
SHOULD_INVOKE=${1:-"true"}

if [[ $SHOULD_INVOKE == "true" ]]; then
	install_rsyslog_file_conf
fi
